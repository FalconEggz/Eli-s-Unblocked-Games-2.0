// Disable context menu on a right click for desktop operating systems
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});
