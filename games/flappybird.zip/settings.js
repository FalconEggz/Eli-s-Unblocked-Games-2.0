ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1302586.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 64308088, 64308085, 64308079, 64308041, 64308091, 64308082, 64308078, 64308080, 64308083, 64308093, 64308057, 64308035, 64308071, 64308087, 64308086 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
